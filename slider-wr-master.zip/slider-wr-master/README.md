SLIDER-WR
=========


Slider-wr es un plugin wordpress, gestion simple de slider.

	<?php
	  /*
	  * Slider Wr Simple
	  *
	  * @param int or string $arg (wp_slider.ID, wp_slider.slider_name).
	  * @return string.
	  *
	  **/
	  echo slider_wr($arg);
	?>
	

	
	

